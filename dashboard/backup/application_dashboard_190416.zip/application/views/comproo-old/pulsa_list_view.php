<div class="section-list-pulsa gerai-provider-pulsa" style="margin-top:75px">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
          <h3 class="page-header">Topup Pulsa</h3>
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p>
      </div>
    </div>
  
      <div class="main_portofolio">
         <a href="<?php echo site_url('pulsa/topup').'/'.'tri'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: orange">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/3.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'telkomsel'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: red">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/telkomsel.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'indosat'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: yellow">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/indosat.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'xl'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background:#1b69bb">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/xl.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'esia'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: #70baaa">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/esia.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'smartfren'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: #eb5157">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/smartfren.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'flexi'; ?>">
           <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: #4fa4da">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/flexi.png" class="img-responsive">
          </div>
         </a>
         <a href="<?php echo site_url('pulsa/topup').'/'.'axis'; ?>">
          <div class="col-md-3 col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; background: purple">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/axis.png" class="img-responsive">
          </div>
         </a>
      </div>
 
  </div>
</div>