<div class="page-banner" style="padding:70px 0 20px 0;background: url(images/slide-02-bg.jpg) center #f9f9f9;">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="text-center">Tentang Kami</h2>
        <!-- <p>We Are Professional</p> -->
      </div>
    </div>
  </div>
</div>

<div class="contact" style="margin:50px 0px;">
  <div class="container">

      <div class="col-md-7">
        <div>
          <h3 class="page-header">Perusahaan</h3>
        </div>
        <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
          It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Sed ut perspiciatis unde omnis iste natus error sit volup accusantium. Lorem ipsum dolor sit amet, consectetur.
        </p>
      </div>

      <div class="col-md-5">
        <img src="<?php echo base_url('assets/compro/IMAGE/mockup_aboutus.png'); ?>" class="img-responsive" />
      </div>
 
  </div>
</div>