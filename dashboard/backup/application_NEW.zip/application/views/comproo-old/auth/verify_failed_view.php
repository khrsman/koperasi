<div class="login-box" style="margin-top:0px;">
  <div class="login-box-body">
    <h4><center>Kode Verifikasi Tidak Valid</center></h4>
    <p class="login-box-msg">
      Jika anda belum terdaftar silahkan lakukan pendaftaran (<a href="<?php echo site_url('auth/signup'); ?>">klik di sini</a>).
    </p>
  </div><!-- /.login-box-body -->
</div><!-- /.login-box -->