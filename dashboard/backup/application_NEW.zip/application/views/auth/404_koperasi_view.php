<div class="container" style="margin-top:80px;">
  <div class="col-md-8 col-md-offset-2">
  <h1>Fitur ini hanya tersedia untuk anggota koperasi</h1>
  </div>
</div>

