<style type="text/css">
   .hr-color{
      margin:7px 0; display: block; width: 60%; height: 2px; border: 0; border-top: 1px solid #009bbd; margin: 1em 0; padding: 0;     
   }
</style>

<!-- <div  class="main_about_us" style="padding: 10px 0;border-bottom:1px solid #D4D4D4;background: #1BBC9B;color: white;margin-top:1px;">

   <div class="container">

      <div class="row">

         <div class="col-md-12 col-xs-12">

            <div class="text-center">

               <marquee>

                  Welcome to Gerai Transaction of Sanmada Mega Indonesia

               </marquee>

            </div>

         </div>

      </div>

   </div>

</div> -->

<div  class="main_about_us">

   <!-- <div class="container"> -->

      <div class="row">

         <div class="col-md-8 col-md-offset-2 col-xs-12">

            <div class="text-center">

               <h2>GERAI LUMRAH</h2>

               <p>

                  Gerai transaction  merupakan sebuah one stop solution untuk pembayaran berbagai tagihan anda yang menawarkan pengalaman belanja online cepat, aman dan nyaman dengan produk-produk dalam kategori yang kami sediakan di bawah ini. Gerai Transaction selalu memberikan pelanggan yang terbaik termasuk dengan menawarkan beberapa pembayaran pilihan, layanan konsumen dan garansi komitmen.

               </p>

            </div>

         </div>

      </div>

   <!-- </div> -->

</div>



<div class="clear-both"></div>



        

<div  class="main_portofolio ">

  <!--  <div class="container">

      <br> -->

      <!-- <div class="container"> -->

         <br><br>

         <div class="col-md-2 col-xs-6">

            <a href="<?php echo site_url('gerai/pulsa'); ?>">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_pulsa.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Top Up Pulsa</strong></p>

               <!-- <p class="text-center">Semua Operator</p> -->

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="<?php echo site_url('store'); ?>">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_online_store.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Online Shopping</strong></p>



            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_wesel.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Wesel Instan</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="<?php echo site_url('gerai/pembayaran'); ?>">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_pembayaran.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Jasa Pembayaran</strong></p>

            </a>

         </div>





         <div class="col-md-2 col-xs-6">

            <a href="<?php echo site_url('gerai/reservasi'); ?>">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_reservasi.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Reservasi</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_pinjaman.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Pinjaman</strong></p>

            </a>

         </div>


         <div class="clear-both"></div>
         <br><br>



         
         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_pegadaian.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Pegadaian</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="https://www.google.co.id/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=currency%20rupiah" target="_blank">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_penukaran_uang.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Penukaran Uang</strong></p>

            </a>

         </div>





         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_asuransi.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Asuransi & Investasi</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_emas.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Emas</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="#">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_infaq.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Infaq & Zakat</strong></p>

            </a>

         </div>



         <div class="col-md-2 col-xs-6">

            <a href="<?php echo site_url('gerai/trading'); ?>">

               <center>

                  <img src="<?php echo base_url('assets/compro/IMAGE/cover_main/cover_circle_tagihan.png');?>" class="img-responsive" width="70%">
                  <hr class="hr-color">
               </center>

               <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Trading (Equities&Forex)</strong></p>

            </a>

         </div>



         <br><br>



      <!-- </div> -->



      

   <!-- </div> -->

</div>



<div class="clear-both"></div>

<!-- <div  class="cl-md-12 main_block main_block_light_green" style="margin-top:50px">

  <h3>Anda tidak perlu lagi khawatir ketika membeli dan melakukan pembayaran apapun.</h3>

</div> -->

