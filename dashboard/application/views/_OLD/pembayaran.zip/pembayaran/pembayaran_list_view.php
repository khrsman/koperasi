<div class="section-list-pulsa gerai-provider-pulsa" style="margin-top:75px">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

          <h3 class="page-header">Jasa Pembayaran</h3>

          <!-- <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p> -->

      </div>

    </div>

  

      <div class="main_portofolio">

        <div class="row row-centered">

        

         <a href="<?php echo site_url('gerai/pembayaran/charge').'/pln_pascabayar'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': red">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/pln.png" class="img-responsive">

          </div>

         </a>

         <a href="<?php echo site_url('gerai/pembayaran/charge').'/pln_prabayar'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': yellow">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/listrikprabayar.png" class="img-responsive">

          </div>

         </a>

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background':#1b69bb">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/speedy.png" class="img-responsive">

          </div>

         </a>

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': #eb5157">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/telkom.png" class="img-responsive">

          </div>

         </a>

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': #eb5157">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/flexi.png" class="img-responsive">

          </div>

         </a>


         <a href="<?php echo '#'; ?>">
          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': purple">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/aetra.png" class="img-responsive">
          </div>
         </a>


        </div>

        <div class="row row-centered">

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': #70baaa">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/kartuhalo.png" class="img-responsive">

          </div>

         </a>

          <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai " style="padding:20px; margin: auto auto; 'background': orange">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/xplor.png" class="img-responsive">

          </div>

         </a>



         <a href="<?php echo '#'; ?>">

           <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': #4fa4da">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/tcash.png" class="img-responsive">

          </div>

         </a>

         <a href="<?php echo '#'; ?>">
          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': purple">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/palyja.png" class="img-responsive">
          </div>
         </a>

         <a href="<?php echo '#'; ?>">
          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': purple">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/indosatmatrix.png" class="img-responsive">
          </div>
         </a>

         <a href="<?php echo '#'; ?>">
          <div class="col-md-2 col-centereds col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': purple">
           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/pembayaran/commonwealth.png" class="img-responsive">
          </div>
         </a>


        </div>

      </div>

 

  </div>

</div>