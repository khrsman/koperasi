


<div class="page-banner" style="padding:70px 0 20px 0;background: url(images/slide-02-bg.jpg) center #f9f9f9;">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2 class="text-center">About Us</h2>
        <!-- <p>We Are Professional</p> -->
      </div>
    </div>
  </div>
</div>

<div class="contact" style="margin:50px 0px;">
  <div class="container">

      <div class="col-md-7">
        <div>
          <h3 class="page-header">Perusahaan</h3>
        </div>
        <p>
         PT SANMADA MEGA INDONESIA (SMI), is a community based organization focused on empowering Microfinance institutions and SME Economic Development through value creation and optimization of their resources with strategic implementation of technology to elevate them to a digital economy. Conceived in 2012 and established in 2015 by a group of bankers and successful businesmen with the mission and unique value proposition to make “Everyone’s” dream a reality. We enable, empower, advise, provide access to capital, train and manage MFIs – providing IT solutions for sustainable microfinance development.
        </p>

        <p>

        <i>“Give me a lever long enough and a pivot on which to place it, and I shall move the world.”  Archimedes.</i>

        </p>
      </div>

      <div class="col-md-5">
        <!-- <img src="<?php //echo base_url('assets/compro/IMAGE/mockup_aboutus.png'); ?>" class="img-responsive" /> -->
      </div>
 
  </div>
</div>


<section class="content-header">
    <h1>
About Us
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Dashboard</a></li>
    </ol>
</section>
<section class="content">
<div class="row">
    <div class="col-md-12">
        <!-- USERS LIST -->
        <div class="box box-primary">
 <div>
          <h3 class="page-header">Perusahaan</h3>
        </div>
        <p>
         PT SANMADA MEGA INDONESIA (SMI), is a community based organization focused on empowering Microfinance institutions and SME Economic Development through value creation and optimization of their resources with strategic implementation of technology to elevate them to a digital economy. Conceived in 2012 and established in 2015 by a group of bankers and successful businesmen with the mission and unique value proposition to make “Everyone’s” dream a reality. We enable, empower, advise, provide access to capital, train and manage MFIs – providing IT solutions for sustainable microfinance development.
        </p>

        <p>

        <i>“Give me a lever long enough and a pivot on which to place it, and I shall move the world.”  Archimedes.</i>

        </p>
      </div>
        </div>
        </div>
        </div>
</section>


