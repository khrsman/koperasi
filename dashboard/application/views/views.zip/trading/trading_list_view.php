<div class="section-list-pulsa gerai-provider-pulsa" >

  

    <div class="row">

      <div class="col-md-12">

          <h3 class="page-header">Trading</h3>

          <!-- <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.</p> -->

      </div>

    </div>

  

      <div class="main_portofolio">

        <div class="row row-centered">

        

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centered col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': red">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/trading/equities.png" class="img-responsive">
           <!-- <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Equities</strong></p> -->
          </div>

         </a>

         <a href="<?php echo '#'; ?>">

          <div class="col-md-2 col-centered col-xs-6 text-center box-gerai" style="padding:20px; margin: auto auto; 'background': yellow">

           <img src="<?php echo base_url('assets/compro'); ?>/IMAGE/provider/trading/forex.png" class="img-responsive">
           <!-- <p class="text-center" style="font-size:18px;margin-bottom:0px;"><strong>Forex</strong></p> -->
          </div>

         </a>



        </div>

      </div>

 

 

</div>